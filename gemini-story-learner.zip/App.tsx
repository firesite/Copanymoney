
import React, { useState, useCallback } from 'react';
import { TranslationResult, SelectionInfo } from './types';
import { generateStory, translateText, generateImageForText } from './services/geminiService';
import StoryGenerator from './components/StoryGenerator';
import StoryDisplay from './components/StoryDisplay';
import TranslationModal from './components/TranslationModal';

const App: React.FC = () => {
    const [story, setStory] = useState<string>('');
    const [isLoadingStory, setIsLoadingStory] = useState<boolean>(false);
    const [isLoadingTranslation, setIsLoadingTranslation] = useState<boolean>(false);
    const [modalData, setModalData] = useState<TranslationResult | null>(null);
    const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

    const handleGenerateStory = useCallback(async (genre: string, length: string) => {
        setIsLoadingStory(true);
        setStory('');
        try {
            const newStory = await generateStory(genre, length);
            setStory(newStory);
        } catch (error) {
            console.error("Error generating story:", error);
            alert("Failed to generate a new story. Please check the console for details.");
        } finally {
            setIsLoadingStory(false);
        }
    }, []);
    
    const handleUseCustomText = useCallback((text: string) => {
        setStory(text);
    }, []);

    const processAndShowTranslation = useCallback(async (text: string) => {
        setIsModalOpen(true);
        setIsLoadingTranslation(true);
        setModalData(null);

        try {
            const [translatedText, imageUrl] = await Promise.all([
                translateText(text),
                generateImageForText(text)
            ]);

            setModalData({
                original: text,
                translated: translatedText,
                imageUrl: imageUrl,
            });
        } catch (error) {
            console.error("Error processing translation and image:", error);
            alert("Failed to get translation or image. Please check the console for details.");
            setIsModalOpen(false);
        } finally {
            setIsLoadingTranslation(false);
        }
    }, []);

    const handleWordClick = useCallback((word: string) => {
        const cleanedWord = word.replace(/[.,!?;:"']/g, '');
        if (cleanedWord) {
            processAndShowTranslation(cleanedWord);
        }
    }, [processAndShowTranslation]);

    const handleSentenceTranslate = useCallback((sentence: string) => {
        processAndShowTranslation(sentence);
    }, [processAndShowTranslation]);

    const closeModal = useCallback(() => {
        setIsModalOpen(false);
        setModalData(null);
    }, []);

    return (
        <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col items-center p-4 sm:p-6 md:p-8 font-sans">
            <header className="w-full max-w-4xl text-center mb-8">
                <h1 className="text-4xl sm:text-5xl font-bold text-sky-400 mb-2">
                    قصص Gemini لتعلم الإنجليزية
                </h1>
                <p className="text-lg text-slate-400">
                    اختر نوع وطول القصة، أو أدخل نصًا بنفسك، ثم انقر على الكلمات لتعلمها
                </p>
            </header>

            <main className="w-full max-w-4xl flex-grow flex flex-col items-center">
                <StoryGenerator 
                    onGenerate={handleGenerateStory} 
                    onUseCustomText={handleUseCustomText} 
                    isLoading={isLoadingStory} 
                />
                <StoryDisplay
                    story={story}
                    onWordClick={handleWordClick}
                    onSentenceTranslate={handleSentenceTranslate}
                    isLoading={isLoadingStory}
                />
            </main>

            <TranslationModal
                isOpen={isModalOpen}
                onClose={closeModal}
                isLoading={isLoadingTranslation}
                data={modalData}
            />

            <footer className="w-full max-w-4xl text-center mt-8 py-4 border-t border-slate-700">
                <p className="text-slate-500">Powered by Gemini & React</p>
            </footer>
        </div>
    );
};

export default App;
