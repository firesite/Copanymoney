
import { GoogleGenAI } from "@google/genai";

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Pexels API Configuration
const PEXELS_API_KEY = 'SGQdDuzSydKyQeZTrr845s32wTqYfP0wyeABrvcKzLAQdCWT8ajEVRN0';
const PEXELS_API_URL = 'https://api.pexels.com/v1/search';


export const generateStory = async (genre: string, length: string): Promise<string> => {
    const lengthMap: { [key: string]: string } = {
        'short': 'around 100-150 words',
        'medium': 'around 200-250 words',
        'long': 'around 300-350 words',
    };
    const wordCount = lengthMap[length] || 'around 100-150 words';

    const prompt = `Write a story that is ${wordCount} long, in simple, colloquial American English. The story should be suitable for an intermediate English learner. The genre should be ${genre}.`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt
        });
        return response.text;
    } catch (error) {
        console.error("Error in generateStory:", error);
        throw new Error("Failed to generate story from API.");
    }
};

export const translateText = async (text: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Translate the following English text into Arabic. Only return the translation. Text: "${text}"`
        });
        return response.text;
    } catch (error) {
        console.error("Error in translateText:", error);
        throw new Error("Failed to translate text from API.");
    }
};

export const generateImageForText = async (text: string): Promise<string> => {
    try {
        const query = text.trim();
        const response = await fetch(`${PEXELS_API_URL}?query=${encodeURIComponent(query)}&per_page=1`, {
            headers: {
                'Authorization': PEXELS_API_KEY
            }
        });

        if (!response.ok) {
            console.error(`Pexels API error: ${response.statusText}`);
            throw new Error(`Pexels API request failed with status ${response.status}`);
        }

        const data = await response.json();

        if (data.photos && data.photos.length > 0) {
            // Use 'large' for good quality. Other options: original, large2x, medium, small, portrait, landscape, tiny.
            return data.photos[0].src.large;
        }
        
        console.warn(`No image found on Pexels for query: "${query}"`);
        // Return a placeholder if no image is found to avoid breaking the UI
        return `https://via.placeholder.com/800x600.png?text=No+Image+Found+for+'${encodeURIComponent(query)}'`;

    } catch (error) {
        console.error("Error fetching image from Pexels:", error);
        // Return a placeholder if the API call fails
        return 'https://via.placeholder.com/800x600.png?text=Error+Loading+Image';
    }
};
