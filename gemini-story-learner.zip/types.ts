
export interface TranslationResult {
  original: string;
  translated: string;
  imageUrl: string;
}

export interface SelectionInfo {
  text: string;
  position: {
    top: number;
    left: number;
  };
}
   