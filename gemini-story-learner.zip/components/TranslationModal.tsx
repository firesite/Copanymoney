
import React, { useCallback } from 'react';
import { TranslationResult } from '../types';
import Spinner from './Spinner';
import { CloseIcon } from './icons/CloseIcon';
import { SpeakerIcon } from './icons/SpeakerIcon';

interface TranslationModalProps {
    isOpen: boolean;
    onClose: () => void;
    isLoading: boolean;
    data: TranslationResult | null;
}

const TranslationModal: React.FC<TranslationModalProps> = ({ isOpen, onClose, isLoading, data }) => {
    if (!isOpen) return null;

    const handleSpeak = useCallback(() => {
        if (data && 'speechSynthesis' in window) {
            window.speechSynthesis.cancel(); // Stop any currently playing speech
            const utterance = new SpeechSynthesisUtterance(data.original);
            utterance.lang = 'en-US';
            window.speechSynthesis.speak(utterance);
        } else {
            console.error("Speech synthesis is not supported in this browser.");
            alert("Sorry, your browser doesn't support text-to-speech.");
        }
    }, [data]);

    return (
        <div 
            className="fixed inset-0 bg-black bg-opacity-75 flex justify-center items-center z-50 p-4"
            onClick={onClose}
            aria-modal="true"
            role="dialog"
        >
            <div
                className="bg-slate-800 rounded-2xl shadow-2xl w-full max-w-md mx-auto transform transition-all duration-300 ease-out scale-95 opacity-0 animate-fade-in-scale"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="p-6 relative">
                    <button
                        onClick={onClose}
                        className="absolute top-4 right-4 text-slate-400 hover:text-white transition-colors"
                        aria-label="Close modal"
                    >
                        <CloseIcon />
                    </button>

                    {isLoading ? (
                        <div className="flex flex-col items-center justify-center h-80">
                            <Spinner />
                            <p className="mt-4 text-slate-300">...جاري جلب الترجمة والصورة</p>
                        </div>
                    ) : data ? (
                        <div className="flex flex-col items-center text-center">
                            <div className="w-full h-64 bg-slate-700 rounded-lg mb-4 overflow-hidden shadow-inner">
                                <img
                                    src={data.imageUrl}
                                    alt={`Generated image for "${data.original}"`}
                                    className="w-full h-full object-cover"
                                />
                            </div>
                            <div className="flex items-center justify-center gap-3">
                                <h2 className="text-2xl font-bold text-sky-400 break-words">
                                    {data.original}
                                </h2>
                                <button
                                    onClick={handleSpeak}
                                    className="text-slate-400 hover:text-sky-400 transition-colors focus:outline-none focus:ring-2 focus:ring-sky-500 rounded-full"
                                    aria-label="Pronounce text"
                                >
                                    <SpeakerIcon />
                                </button>
                            </div>
                            <p className="mt-2 text-3xl font-semibold text-slate-100" lang="ar" dir="rtl">
                                {data.translated}
                            </p>
                        </div>
                    ) : null}
                </div>
            </div>
            <style>{`
                @keyframes fadeInScale {
                    from { opacity: 0; transform: scale(0.95); }
                    to { opacity: 1; transform: scale(1); }
                }
                .animate-fade-in-scale {
                    animation: fadeInScale 0.3s forwards cubic-bezier(0.16, 1, 0.3, 1);
                }
            `}</style>
        </div>
    );
};

export default TranslationModal;
