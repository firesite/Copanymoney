
import React, { useState } from 'react';
import Spinner from './Spinner';

interface StoryGeneratorProps {
    onGenerate: (genre: string, length: string) => void;
    onUseCustomText: (text: string) => void;
    isLoading: boolean;
}

const StoryGenerator: React.FC<StoryGeneratorProps> = ({ onGenerate, onUseCustomText, isLoading }) => {
    const [activeTab, setActiveTab] = useState<'generate' | 'custom'>('generate');
    const [genre, setGenre] = useState('daily-life');
    const [length, setLength] = useState('short');
    const [customText, setCustomText] = useState('');

    const handleGenerateClick = () => {
        onGenerate(genre, length);
    };

    const handleCustomTextClick = () => {
        if (customText.trim()) {
            onUseCustomText(customText.trim());
        } else {
            alert("Please enter some text in the text box.");
        }
    };

    const renderTabs = () => (
        <div className="flex mb-4 rounded-lg bg-slate-700 p-1">
            <button
                onClick={() => setActiveTab('generate')}
                className={`w-1/2 p-2 rounded-md font-semibold transition-colors duration-200 ${
                    activeTab === 'generate' ? 'bg-sky-600 text-white' : 'text-slate-300 hover:bg-slate-600'
                }`}
            >
                إنشاء قصة
            </button>
            <button
                onClick={() => setActiveTab('custom')}
                className={`w-1/2 p-2 rounded-md font-semibold transition-colors duration-200 ${
                    activeTab === 'custom' ? 'bg-sky-600 text-white' : 'text-slate-300 hover:bg-slate-600'
                }`}
            >
                استخدام نص مخصص
            </button>
        </div>
    );

    const renderGenerateControls = () => (
        <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label htmlFor="genre" className="block text-sm font-medium text-slate-400 mb-1">نوع القصة (Genre)</label>
                    <select
                        id="genre"
                        value={genre}
                        onChange={(e) => setGenre(e.target.value)}
                        className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 text-white focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
                    >
                        <option value="daily-life">Daily Life</option>
                        <option value="fantasy">Fantasy</option>
                        <option value="sci-fi">Sci-Fi</option>
                        <option value="mystery">Mystery</option>
                        <option value="comedy">Comedy</option>
                        <option value="adventure">Adventure</option>
                    </select>
                </div>
                <div>
                    <label htmlFor="length" className="block text-sm font-medium text-slate-400 mb-1">طول القصة (Length)</label>
                    <select
                        id="length"
                        value={length}
                        onChange={(e) => setLength(e.target.value)}
                        className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 text-white focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
                    >
                        <option value="short">Short (~100 words)</option>
                        <option value="medium">Medium (~200 words)</option>
                        <option value="long">Long (~300 words)</option>
                    </select>
                </div>
            </div>
            <button
                onClick={handleGenerateClick}
                disabled={isLoading}
                className="w-full flex items-center justify-center px-6 py-3 bg-sky-600 text-white font-semibold rounded-lg shadow-md hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-2 focus:ring-offset-slate-900 transition-all duration-200 disabled:bg-slate-500 disabled:cursor-not-allowed"
            >
                {isLoading ? (
                    <>
                        <Spinner />
                        <span className="ml-2">جاري إنشاء القصة...</span>
                    </>
                ) : (
                    "احصل على قصة جديدة"
                )}
            </button>
        </div>
    );

    const renderCustomTextControls = () => (
        <div className="space-y-4">
            <textarea
                value={customText}
                onChange={(e) => setCustomText(e.target.value)}
                placeholder="أدخل أو الصق النص الإنجليزي هنا..."
                className="w-full h-32 bg-slate-700 border border-slate-600 rounded-md p-2 text-white focus:ring-2 focus:ring-sky-500 focus:border-sky-500 resize-y"
            />
            <button
                onClick={handleCustomTextClick}
                disabled={isLoading}
                className="w-full flex items-center justify-center px-6 py-3 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-2 focus:ring-offset-slate-900 transition-all duration-200 disabled:bg-slate-500 disabled:cursor-not-allowed"
            >
                استخدم هذا النص
            </button>
        </div>
    );

    return (
        <div className="mb-8 w-full bg-slate-800 p-6 rounded-lg shadow-lg">
            {renderTabs()}
            {activeTab === 'generate' ? renderGenerateControls() : renderCustomTextControls()}
        </div>
    );
};

export default StoryGenerator;
