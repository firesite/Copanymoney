import React from 'react';
import Spinner from './Spinner';
import { TranslateIcon } from './icons/TranslateIcon';

interface StoryDisplayProps {
    story: string;
    isLoading: boolean;
    onWordClick: (word: string) => void;
    onSentenceTranslate: (sentence: string) => void;
}

const StoryDisplay: React.FC<StoryDisplayProps> = ({ story, isLoading, onWordClick, onSentenceTranslate }) => {

    if (isLoading) {
        return (
            <div className="w-full bg-slate-800 p-8 rounded-lg shadow-lg flex justify-center items-center h-64">
                <Spinner />
            </div>
        );
    }

    if (!story) {
        return (
            <div className="w-full bg-slate-800/50 border-2 border-dashed border-slate-600 p-8 rounded-lg flex justify-center items-center h-64 text-slate-500">
                <p>ستظهر قصتك هنا. اضغط على الزر أعلاه للبدء.</p>
            </div>
        );
    }

    // Split story into sentences. This regex splits after a sentence-ending punctuation mark followed by a space.
    const sentences = story.split(/(?<=[.!?])\s+/).filter(s => s.trim() !== '');

    return (
        <div className="w-full bg-slate-800 p-6 sm:p-8 rounded-lg shadow-lg">
            <div className="space-y-2" style={{ direction: 'ltr' }}>
                {sentences.map((sentence, index) => (
                    <div key={index} className="relative group rounded-md transition-colors hover:bg-slate-700/50">
                        <p className="text-xl sm:text-2xl leading-loose p-2">
                            {sentence.split(/(\s+)/).map((segment, i) => {
                                if (segment.trim() === '') {
                                    return <React.Fragment key={i}>{segment}</React.Fragment>;
                                }
                                return (
                                    <span
                                        key={i}
                                        onClick={() => onWordClick(segment)}
                                        className="cursor-pointer hover:bg-sky-500/30 rounded-md transition-colors p-1 -m-1"
                                    >
                                        {segment}
                                    </span>
                                );
                            })}
                        </p>
                        <button
                            onClick={() => onSentenceTranslate(sentence.trim())}
                            className="absolute top-1/2 -right-4 transform -translate-y-1/2 p-2 bg-sky-600 text-white rounded-full shadow-lg opacity-0 group-hover:opacity-100 focus:opacity-100 transition-all duration-200 ease-in-out hover:scale-110"
                            aria-label="Translate sentence"
                        >
                            <TranslateIcon />
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default StoryDisplay;